#define GOATS_RC33_STEP1_IMPL
#include "goats_spi_diag.h"
#include "esphome/core/log.h"
#include "goats_track_catalog.h"
#include "goats_laptimer.h"
#include "goats_m9n_cfg.h"
#include "goats_ubx_m9n_ak97_full.h"
#include "goats_lap_storage.h"
#include "goats_rc33_step1.h"
#include "goats_step3_runtime.h"
#include "rc33_goats_postlap_ui.h"
#include "goats_racing_step2.h"
#include "goats_postfix_runtime.h"
#include <cmath>
#include <stdio.h>
#include <string.h>
namespace esphome { namespace goats_spi_diag {
static const char *const TAG="goats_spi_diag";
void GoatsSpiDiag::cmd_(uint8_t v) {
  digitalWrite(DC, LOW);
  digitalWrite(CS, LOW);
  spi_.transfer(v);
  digitalWrite(CS, HIGH);
}
void GoatsSpiDiag::data_(uint8_t v) {
  digitalWrite(DC, HIGH);
  digitalWrite(CS, LOW);
  spi_.transfer(v);
  digitalWrite(CS, HIGH);
}
void GoatsSpiDiag::controller_init_() {
  ESP_LOGI(TAG, "INIT: ST7306 %s, inizio",lcd_high_power_?"HPM 51Hz":"LPM");
  cmd_(0xD6); data_(0x17); data_(0x02);
  cmd_(0xD1); data_(0x01);
  cmd_(0xC0); data_(0x08); data_(0x00);
  cmd_(0xC1); for (int i=0;i<4;i++) data_(0x2C);
  cmd_(0xC2); for (int i=0;i<4;i++) data_(0x26);
  cmd_(0xC4); for (int i=0;i<4;i++) data_(0x42);
  cmd_(0xC5); for (int i=0;i<4;i++) data_(0x32);
  // LFRA=5 -> LPM 8Hz; legacy LFRA=2 limited the panel to 1Hz.
  cmd_(0xB2); data_(fast_display_?0x15:0x12);
  const uint8_t b3[] = {0xE5,0xF6,0x05,0x46,0x77,0x77,0x77,0x77,0x76,0x45};
  cmd_(0xB3); for (uint8_t v : b3) data_(v);
  const uint8_t b4[] = {0x05,0x46,0x77,0x77,0x77,0x77,0x77,0x76,0x45};
  cmd_(0xB4); for (uint8_t v : b4) data_(v);
  cmd_(0xB7); data_(0x13);
  cmd_(0xB0); data_(0x64);
  cmd_(0xC9); data_(0x00);
  cmd_(0x11); delay(400);
  // ST7306 sections 8.2.3/8.2.23: HFRA=1 + OSC 0x80,E9 -> HPM 51Hz.
  // Program once after sleep-out; never toggle power modes during RAMWR.
  if(lcd_high_power_){cmd_(0xD8);data_(0x80);data_(0xE9);}
  cmd_(0x36); data_(0x80);
  // DTFORM XDE is active-low: compensate the MY=1 page order (MADCTL 0x80).
  // BPS remains 1: the same three-byte/24-bit wire format.
  cmd_(0x3A); data_(lcd_data_swap_?0x01:0x11);
  cmd_(0xB9); data_(0x20);
  cmd_(0xB8); data_(0x09);
  cmd_(0xD0); data_(0xFF);
  cmd_(0x72); data_(0x13);
  cmd_(lcd_high_power_?0x38:0x39);
  cmd_(0x29); delay(200);
  ESP_LOGI(TAG, "INIT: sequenza comandi trasmessa; nessun ACK LCD disponibile");
}
#include "goats_font_bitmap.h"
#include "goats_speed_95.h"
#include "goats_layout39_font.h"
static int font_width_(const char* str,int size) {
 auto t=goats_font::table(size);int w=0;
 for(int i=0;str[i];i++)w+=t.g[goats_font::idx(str[i])].advance;
 return w;
}
void GoatsSpiDiag::font_text_(int x,int y,const char* str,int size,uint8_t color,int align) {
 auto t=goats_font::table(size);int xx=x;
 const int w=font_width_(str,size);
 if(align==1)xx-=w/2;else if(align==2)xx-=w;
 for(int k=0;str[k];k++){
  const auto &g=t.g[goats_font::idx(str[k])];
  const uint8_t *pix=t.data+g.off;
  for(int yy=0;yy<g.h;yy++)for(int col=0;col<g.w;col++){
   int j=yy*g.w+col;
   if(pix[j>>3]&(0x80>>(j&7)))pixel_(xx+col,y+g.top+yy,color);
  }
  xx+=g.advance;
 }
}
// V039: speed bitmap native-size; no enlarged 2x2 pixels.
// Glyphs are rasterized once from Roboto Condensed Bold 95pt.
void GoatsSpiDiag::speed_native_(int cx,int cy,const char *value,uint8_t color){
  int width=0,height=0;
  for(int i=0;value[i];i++){
    int ix=goats_speed_font::index(value[i]);if(ix<0)continue;
    auto g=goats_speed_font::glyphs[ix];
    width+=g.w+2;
    if(g.h>height)height=g.h;
  }
  if(width<=0)return;
  width-=2;
  const int left=cx-width/2;
  const int top=cy-height/2;
  int cursor=0;
  for(int i=0;value[i];i++){
    int ix=goats_speed_font::index(value[i]);if(ix<0)continue;
    auto g=goats_speed_font::glyphs[ix];
    const uint8_t *bits=goats_speed_font::bitmap+g.offset;
    const int yy0=top+((value[i]=='.') ? (height-g.h-2) : (height-g.h)/2);
    for(int yy=0;yy<g.h;yy++)for(int xx=0;xx<g.w;xx++){
      const int j=yy*g.w+xx;
      const bool on=(bits[j>>3]&(0x80>>(j&7)))!=0;
      // V039: rifinitura conservativa SOLO del font velocita' a 95px.
      // Completa un foro di un singolo pixel quando tutti gli 8 vicini
      // appartengono al tratto. Non interviene su spigoli, segni o decimali.
      bool repair=false;
      if(!on && xx>0 && yy>0 && xx+1<g.w && yy+1<g.h){
        repair=true;
        for(int dy=-1;dy<=1 && repair;dy++)for(int dx=-1;dx<=1;dx++){
          if(dx==0 && dy==0)continue;
          const int k=(yy+dy)*g.w+(xx+dx);
          if(!(bits[k>>3]&(0x80>>(k&7)))){repair=false;break;}
        }
      }
      if(on || repair){
        const int tx=left+cursor+xx,ty=yy0+yy;
        if(tx>=7&&tx<=222&&ty>=62&&ty<=162)pixel_(tx,ty,color);
      }
    }
    cursor+=g.w+2;
  }
}
// Etichette verticali: bitmap trasferite dal firmware RLCD Layout 8 originale.
// Layout logico 400x300 (coordinate RLCD Layout 8).
// Il pannello fisico 300x400 e' ruotato: px=299-y, py=x.
// Manteniamo l'impacchettamento sperimentale V018, ora confermato leggibile.
// V039: conversione ST7306 RBW da TomatoGFX, ST7306_4P2_RBW_Driver::writePoint().
// Conferma colori: Zephyr drivers/display/display_st730x.c: 0=off, 1=red,
// 2=white, 3=black. Non utilizzare dithering alternato px%2.
// UN BYTE = 2x2 pixel fisici; sequenza bit:
//   x pari, y pari: bit 7 (color bit1), bit 5 (color bit0)
//   x pari, y disp: bit 6, bit 4
//   x disp, y pari: bit 3, bit 1
//   x disp, y disp: bit 2, bit 0
// L'indirizzo di memoria resta 150 byte/riga * 200 righe = 30000 byte.
void GoatsSpiDiag::pixel_(int x,int y,uint8_t color) {
 if(x<0||x>=400||y<0||y>=300)return;
 const int px=299-y,py=x;
 const int idx=(py/2)*150+(px/2);
 const int parity_y=py&1,parity_x=px&1;
 const int bit1=7-(parity_x*4+parity_y);
 const int bit0=bit1-2;
 uint8_t c=(color==BLACK)?3:((color==RED)?1:2);
 const uint8_t mask=uint8_t((1U<<bit1)|(1U<<bit0));
 const uint8_t v=uint8_t((((c>>1)&1U)<<bit1)|((c&1U)<<bit0));
 framebuffer_[idx]=(framebuffer_[idx]&uint8_t(~mask))|v;
}
void GoatsSpiDiag::rect_(int x,int y,int w,int h,uint8_t color){
 int x0=x<0?0:x,y0=y<0?0:y,x1=x+w>400?400:x+w,y1=y+h>300?300:y+h;
 for(int yy=y0;yy<y1;yy++)for(int xx=x0;xx<x1;xx++)pixel_(xx,yy,color);
}
void GoatsSpiDiag::border_(int x,int y,int w,int h,uint8_t col){
 rect_(x,y,w,2,col);rect_(x,y+h-2,w,2,col);rect_(x,y,2,h,col);rect_(x+w-2,y,2,h,col);
}
void GoatsSpiDiag::text_(int x,int y,const char *str,uint8_t col,int sz){font_text_(x,y,str,sz,col,0);}
void GoatsSpiDiag::vertical_(int x,int y,const char *str,uint8_t col,int sz){
 // Backwards-compatible fallback for short vertical labels (rotated native font).
 auto t=goats_font::table(sz);int off=0;
 for(int i=0;str[i];i++){
  const auto &g=t.g[goats_font::idx(str[i])];const uint8_t *bits=t.data+g.off;
  for(int yy=0;yy<g.h;yy++)for(int xx=0;xx<g.w;xx++){
   int j=yy*g.w+xx;if(bits[j>>3]&(0x80>>(j&7)))pixel_(x+yy,y+off+xx,col);
  }off+=g.advance;
 }
}
// Disegna +/- centrato sull'altezza dei numeri (anziche' allineato in alto).
// V0.40.4: fix ordine include; Delta Lap, punto decimale in basso come quello della velocita'.
// Disegno font nativo, senza ridimensionamenti: un pixel rimane un pixel.
// Ripara esclusivamente eventuali fori isolati di 1px dentro i tratti pieni;
// nessun filtro su contorni, decimale o segno +/-.
void GoatsSpiDiag::signed_delta_(int center_x,int y,const char* value,int size,uint8_t color) {
  auto t=goats_font::table(size);
  const int total=font_width_(value,size);
  int xx=center_x-total/2;
  const int digit_h=t.g[goats_font::idx('0')].h;
  for(int k=0;value[k];k++){
    const char c=value[k];
    const auto &g=t.g[goats_font::idx(c)];
    const uint8_t *pix=t.data+g.off;
    const bool sign=(k==0 && (c=='+' || c=='-'));
    const int center_adjust=sign ? (digit_h-g.h)/2 : 0;
    const int dot_shift=(c=='.') ? 8 : 0;
    for(int yy=0;yy<g.h;yy++)for(int col=0;col<g.w;col++){
      const int j=yy*g.w+col;
      const bool on=(pix[j>>3]&(0x80>>(j&7)))!=0;
      bool fix=false;
      if(!on && c>='0' && c<='9' && col>0 && yy>0 && col+1<g.w && yy+1<g.h){
        fix=true;
        for(int dy=-1;dy<=1 && fix;dy++)for(int dx=-1;dx<=1;dx++){
          if(dx==0 && dy==0)continue;
          const int q=(yy+dy)*g.w+(col+dx);
          if(!(pix[q>>3]&(0x80>>(q&7)))){fix=false;break;}
        }
      }
      if(on||fix){
        const int tx=xx+col,ty=y+g.top+center_adjust+dot_shift+yy;
        if(tx>=246 && tx<396 && ty>=36 && ty<105)pixel_(tx,ty,color);
      }
    }
    xx+=g.advance;
  }
}

void GoatsSpiDiag::native_label_(int x,int y,const uint8_t *bitmap,int w,int h,uint8_t col){
 for(int yy=0;yy<h;yy++)for(int xx=0;xx<w;xx++){
  const int j=yy*w+xx;if(bitmap[j>>3]&(0x80>>(j&7)))pixel_(x+xx,y+yy,col);
 }
}
uint32_t GoatsSpiDiag::region_(int x,int y,int w,int h,const char *label){
 // BBox trasformata: fisico X=299-logico Y, Y=logico X.
 int px=300-(y+h),py=x,pw=h,ph=w;
 int x0=(px<0?0:px)/6,x1=(px+pw+5)/6;
 int y0=(py<0?0:py)/2,y1=(py+ph+1)/2;
 if(x1>TW)x1=TW;if(y1>TH)y1=TH;
 if(x1<=x0||y1<=y0)return 0;
 uint32_t start=micros();
 cmd_(0x2A);data_(uint8_t(0x05+x0));data_(uint8_t(0x05+x1-1));
 cmd_(0x2B);data_(uint8_t(y0));data_(uint8_t(y1-1));cmd_(0x2C);
 digitalWrite(DC,HIGH);digitalWrite(CS,LOW);
 for(int yy=y0;yy<y1;yy++)spi_.transferBytes(framebuffer_+(yy*TW+x0)*3,nullptr,(x1-x0)*3);
 digitalWrite(CS,HIGH);
 uint32_t t=micros()-start;updates_++;bytes_+=(x1-x0)*(y1-y0)*3;spi_us_+=t;
 if(t>max_us_)max_us_=t;return t;
}
static const uint8_t label_delta_original[] = {0x00,0x00,0xE0,0x3F,0x87,0xBC,0x60,0xC6,0x04,0x60,0xC3,0xFC,0x3F,0x80,0x00,0x00,0x43,0x9C,0x7F,0x86,0x60,0x66,0x07,0xFC,0x7F,0xC0,0x00,0x00,0x07,0xFC,0x7F,0xC0,0x00,0x00,0x02,0x7C,0x67,0xC6,0x64,0x60,0xC6,0x0C,0x3F,0xC1,0xF8,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0C,0x07,0xC3,0xF0,0x71,0x07,0x90,0x1F,0x80,0x3C,0x00,0x46,0x00,0x60,0x07,0xFC,0x7F,0xC6,0x00,0x60,0xC6,0x0C,0x00,0xC0,0x0C,0x7F,0xC7,0xFC,0x00,0x00,0x0C,0x64,0xC6,0x4C,0x64,0xC7,0xFC,0x7F,0xC0,0x00,0x00,0x01,0xF8,0x3F,0x86,0x0C,0x60,0xC6,0x0C,0x7F,0xC7,0xFC,0x00,0x00,0x00};
static const uint8_t label_best_original[] = {0x00,0x00,0x00,0x3C,0x07,0xE0,0x66,0x06,0x60,0x7F,0xC7,0xFC,0x00,0x00,0x00,0x00,0xC0,0x7C,0x3F,0x07,0x10,0x79,0x01,0xF8,0x03,0xC0,0x0C,0x00,0xC0,0x0C,0x00,0xC7,0xFC,0x7F,0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x06,0x00,0x60,0x07,0xFC,0x7F,0xC6,0x00,0x60,0x06,0x00,0x03,0x86,0x7C,0x66,0xC6,0xC4,0x7C,0xC3,0xCC,0x00,0x00,0x00,0x00,0xC6,0x4C,0x64,0xC6,0x4C,0x7F,0xC7,0xFC,0x00,0x00,0x00,0x3F,0xC7,0xFC,0x64,0xC6,0x4C,0x7F,0xC7,0xFC,0x00,0x00,0x00};
// V021: blocchi laterali invertiti rispettando l'orientamento che ha gia' funzionato.
// Limiti disegno: 0..399 x 0..299. Larghezza minima 2 px per bordi.
void GoatsSpiDiag::static_layout_(){
 rect_(0,0,400,300,WHITE);
 rect_(0,29,400,2,BLACK);
 font_text_(7,7,"GPS --/--",16,BLACK,0);
 font_text_(394,7,"GPS INIT",16,BLACK,2);
 // V039: velocita' pulita, senza sottoriquadro/etichetta inferiore.
 border_(1,33,227,137,BLACK);
 // Delta e Best sul lato sinistro della vista fisica.
 border_(230,33,169,75,BLACK);
 border_(230,111,169,59,BLACK);
 // Cronometro a tutta larghezza
 border_(1,173,398,80,BLACK);
 font_text_(10,176,"LAP TIME",16,BLACK,0);
 for(int i=0;i<3;i++)border_(1+133*i,256,132,21,BLACK);
 font_text_(67,258,"S1",16,BLACK,1);
 font_text_(200,258,"S2",16,BLACK,1);
 font_text_(333,258,"S3",16,BLACK,1);
 font_text_(394,282,"AUTO",16,BLACK,2);
}
// V039: font numerico nativo 82px, progressioni X corrette e baseline unica.
void GoatsSpiDiag::lap_big_(int center,int y,const char* value,uint8_t color){
  using namespace goats_layout39_font;
  int width=0;
  for(int i=0;value[i];i++){int n=index(value[i]);if(n>=0)width+=lap_glyphs[n].advance;}
  int cur=center-width/2;
  for(int i=0;value[i];i++){
    const int n=index(value[i]);if(n<0)continue;
    const auto &g=lap_glyphs[n];
    const uint8_t* bits=lap_bits+g.offset;
    for(int yy=0; yy<g.h; yy++)for(int xx=0; xx<g.w; xx++){
      const int j=yy*g.w+xx;
      if((bits[j>>3]>>(7-(j&7)))&1){
         const int tx=cur+xx,ty=y+g.yshift+yy;
         if(tx>=6 && tx<396 && ty>=188 && ty<251)pixel_(tx,ty,color);
      }
    }
    cur+=g.advance;
  }
}
// V039: BEST LAP rasterizzato a 57px, ristretto solo orizzontalmente
// per mantenere la dimensione verticale e rispettare la label laterale.
void GoatsSpiDiag::best_big_(int center_x,int center_y,uint8_t color){
  using namespace goats_layout39_font;
  const int left=center_x-best_width/2;
  const int top=center_y-best_height/2;
  for(int yy=0; yy<best_height; yy++)for(int xx=0; xx<best_width; xx++){
    const int j=yy*best_width+xx;
    if((best_bits[j>>3]>>(7-(j&7)))&1){
      const int tx=left+xx,ty=top+yy;
      if(tx>=247 && tx<396 && ty>=114 && ty<168)pixel_(tx,ty,color);
    }
  }
}

// BEST LAP dinamico, ingrandito e centrato come nella V039.
// Riduce eventualmente la sola larghezza del testo per la fascia da 149 px.
void GoatsSpiDiag::best_dynamic_(int cx,int cy,const char *value,uint8_t color){
 auto t=goats_font::table(60);
 int width=0,min_y=999,max_y=-999;
 for(int k=0;value[k];k++){
   const auto &g=t.g[goats_font::idx(value[k])];
   width+=g.advance;
   if(g.top<min_y)min_y=g.top;
   if(g.top+g.h>max_y)max_y=g.top+g.h;
 }
 if(width<=0||min_y>max_y)return;
 const int height=max_y-min_y;
 const int shown_w=(width>149)?149:width;
 const int start_x=cx-shown_w/2;
 const int shown_h=(height>50)?50:height;
 const int start_y=cy-shown_h/2;
 int cursor=0;
 for(int k=0;value[k];k++){
   const auto &g=t.g[goats_font::idx(value[k])];
   const uint8_t *bits=t.data+g.off;
   for(int yy=0;yy<g.h;yy++)for(int xx=0;xx<g.w;xx++){
     const int j=yy*g.w+xx;
     if(!(bits[j>>3]&(0x80>>(j&7))))continue;
     const int tx=start_x+(cursor+xx)*shown_w/width;
     const int ty=start_y+(g.top+yy-min_y)*shown_h/height;
     if(tx>=246&&tx<396&&ty>=114&&ty<167)pixel_(tx,ty,color);
   }
   cursor+=g.advance;
 }
}
void GoatsSpiDiag::clock_(){
 const uint32_t ms=goats_laptimer_display_current_ms(millis());
 char b[24];snprintf(b,sizeof(b),"%lu:%02lu.%03lu",
  (unsigned long)(ms/60000),(unsigned long)((ms/1000)%60),(unsigned long)(ms%1000));
 static constexpr int CLOCK_Y=188,CLOCK_H=63;
 rect_(6,CLOCK_Y,390,CLOCK_H,WHITE);
 lap_big_(200,CLOCK_Y,b,BLACK);
 region_(6,CLOCK_Y,390,CLOCK_H,"LAP20");
}
void GoatsSpiDiag::status_draw_(){
 if(screen_!=0)return;
 rect_(3,3,394,24,WHITE);
 char b[64];
 const auto &g=goats_m9n::state;
 snprintf(b,sizeof(b),"GPS %u/%u",(unsigned)g.used_sats,(unsigned)g.visible_sats);
 font_text_(7,7,b,16,BLACK,0);
 const auto *t=goats_tracks::get(track_index_);
 const char *name=t?t->name.c_str():"NO TRACK";
 char short_name[26];snprintf(short_name,sizeof(short_name),"%.21s",name);
 // Font 16px nativo; riduci solo se la pista invade l'area GPS.
 int track_font=16;
 while(short_name[0] && font_width_(short_name,track_font)>196){
   const size_t len=strlen(short_name);
   if(len<=1)break;
   short_name[len-1]='\0';
 }
 font_text_(394,7,short_name,track_font,BLACK,2);
 region_(3,3,394,24,"GPS-TOP");
}
void GoatsSpiDiag::auxiliaries_(){
 if(screen_!=0)return;
 char b[40];
 const uint32_t now=millis();
 const float delta=goats_laptimer_display_delta_seconds(now);
 const bool have_delta=std::isfinite(delta);
 const bool worse=have_delta && delta>0.f; // positivo = giro piu lento.
 const uint8_t bg=(have_delta && !worse)?RED:WHITE;
 const uint8_t fg=(bg==RED)?WHITE:BLACK;
 rect_(232,35,165,71,bg);
 native_label_(233,35,label_delta_original,12,72,fg);
 if(have_delta){snprintf(b,sizeof(b),"%+0.3f",(double)delta);}else{strcpy(b,"--.---");}
 const int fs=font_width_(b,52)<=148?52:44;
 signed_delta_(322,48,b,fs,fg);
 region_(232,35,165,71,"DELTA");
 rect_(232,113,165,55,WHITE);
 native_label_(233,113,label_best_original,12,60,BLACK);
 if(goats_laptimer_best_lap_ms()){
   // Best font V039 e' bitmap prerenderizzato del campione 1:22.987.
   // Per i dati veri usiamo un font dinamico, per non mostrare un tempo falso.
   const std::string t=goats_laptimer_best_text();
   best_dynamic_(322,140,t.c_str(),BLACK);
 } else font_text_(322,124,"--:--.---",28,BLACK,1);
 region_(232,113,165,55,"BEST");
 rect_(3,35,223,133,WHITE);
 const float raw=goats_m9n::state.fix?goats_m9n::state.speed_kmh:0.f;
 const float speed=(raw>=3.f)?raw:0.f;
 snprintf(b,sizeof(b),"%.1f",(double)speed);
 speed_native_(114,112,b,BLACK);
 font_text_(10,39,"VELOCITA'",16,BLACK,0);
 region_(3,35,223,133,"SPEED");
 rect_(3,280,394,18,WHITE);
 snprintf(b,sizeof(b),"GIRI %lu",(unsigned long)goats_laptimer_lap_number());
 font_text_(5,280,b,16,BLACK,0);
 font_text_(394,280,auto_track_?"AUTO":"MANUALE",16,BLACK,2);
 region_(3,280,394,18,"GIRI");
 // Settori: delta visualizzato solo se realmente calcolato dall'engine.
 for(int i=0;i<3;i++){
   const int x=2+i*133;
   rect_(x+2,258,126,16,WHITE);
   const float d=goats_laptimer_sector_display_delta_seconds(i,now);
   if(std::isfinite(d)){snprintf(b,sizeof(b),"S%d %+0.2f",i+1,(double)d);}
   else{snprintf(b,sizeof(b),"S%d --",i+1);}
   font_text_(x+66,258,b,16,BLACK,1);
 }
 region_(2,256,396,21,"SECTORS");
}
void GoatsSpiDiag::choose_track_(int idx){
 if(idx==track_index_)return;
 track_index_=idx;goats_laptimer_reset();goats_lap_storage::end();was_running_=false;
 ESP_LOGI(TAG,"Circuito: %s",goats_tracks::get(idx)?goats_tracks::get(idx)->name.c_str():"nessuno");
}
void GoatsSpiDiag::clear_session_(){goats_laptimer_reset();goats_lap_storage::end();was_running_=false;}
void GoatsSpiDiag::gps_poll_(){
 if(!gps_uart_||!gps_configured_)return;
 // Same single reader/parser as DIAG3. Validated raw PVT is handed to RC3.3
 // synchronously by the passive counter observer, never by a second UART read.
 goats_m9n::poll(gps_uart_);
 static std::vector<goats_m9n::NavSample> batch;
 goats_m9n::take_samples(batch,8); // Drain legacy queue; no second engine update.
}
void GoatsSpiDiag::menu_draw_(){
 rect_(0,0,400,300,WHITE);
 const char *name=screen_==1?"MENU":"CIRCUITI";
 font_text_(200,8,name,28,BLACK,1);
 rect_(4,39,392,2,BLACK);
 if(screen_==1){
   const char *labels[]={"GPS STATUS","CIRCUITO","AUTOTRACK","FINE SESSIONE","INFO","INDIETRO"};
   for(int i=0;i<6;i++){
     int y=48+i*37;
     if(menu_item_==i){rect_(10,y,378,34,BLACK);font_text_(24,y+4,labels[i],20,WHITE,0);}
     else font_text_(24,y+4,labels[i],20,BLACK,0);
   }
 }else if(screen_==2){
   const auto &g=goats_m9n::state;char b[64];
   snprintf(b,sizeof(b),"FIX %s  SAT %u/%u",g.fix?"SI":"NO",g.used_sats,g.visible_sats);
   font_text_(16,68,b,20,BLACK,0);
   snprintf(b,sizeof(b),"HDOP %.1f  UBX %.1f Hz",(double)g.hdop,(double)g.pvt_hz);
   font_text_(16,108,b,20,BLACK,0);
   snprintf(b,sizeof(b),"SPEED %.1f km/h",(double)g.speed_kmh);
   font_text_(16,148,b,20,BLACK,0);
 }else if(screen_==3){
   const int n=goats_tracks::tracks.size();
   if(n==0)font_text_(200,105,"NESSUN CIRCUITO",20,BLACK,1);
   else{
     for(int r=0;r<5;r++){
       int k=menu_item_-2+r;
       if(k<0||k>=n)continue;
       const int y=65+r*37;
       const bool selected=k==menu_item_;
       if(selected)rect_(10,y,378,34,BLACK);
       char b[40];snprintf(b,sizeof(b),"%s%.26s",k==track_index_?"* ":"  ",goats_tracks::tracks[k].name.c_str());
       font_text_(20,y+4,b,20,selected?WHITE:BLACK,0);
     }
   }
 }else if(screen_==4){
   font_text_(200,72,"GOATS 4.2 COLOR",28,BLACK,1);
   font_text_(200,124,"V0.40.4 RC - 28/10/26",20,BLACK,1);
   font_text_(200,162,"MG902 / M9N 25Hz",20,BLACK,1);
   font_text_(200,203,goats_lap_storage::ready?"NVS GIRI OK":"NVS GIRI NON DISP.",16,BLACK,1);
 }
 font_text_(200,279,"SU/GIU  INDIETRO  OK",16,BLACK,1);
 region_(0,0,400,300,"MENU");
}
void GoatsSpiDiag::menu_action_(){
 if(screen_==1){
   switch(menu_item_){
     case 0:screen_=2;break;
     case 1:screen_=3;menu_item_=track_index_>=0?track_index_:0;break;
     case 2:auto_track_=!auto_track_;break;
     case 3:clear_session_();screen_=0;static_layout_();break;
     case 4:screen_=4;break;
     default:screen_=0;static_layout_();break;
   }
 } else if(screen_==3){
   if(goats_tracks::get(menu_item_)){choose_track_(menu_item_);auto_track_=false;}
   screen_=0;static_layout_();
 }else{screen_=1;menu_item_=0;}
 if(screen_!=0)menu_draw_();else{status_draw_();clock_();auxiliaries_();}
}
void GoatsSpiDiag::buttons_(){
 const uint32_t now=millis();if(now-last_keys_<45)return;last_keys_=now;
 const int pins[]={KEY_UP,KEY_DOWN,KEY_BACK,KEY_OK};
 uint8_t keys=0;for(int i=0;i<4;i++)if(digitalRead(pins[i]))keys|=1u<<i;
 const uint8_t pressed=old_keys_ & (uint8_t)~keys;old_keys_=keys;
 if(!pressed)return;
 if(screen_==0){
   // Durante la gara solo SU/GIU riservati a luminosita' futura: senza BL non agiscono.
   // OK apre il menu solo a kart fermo, BACK non altera il lap timer.
   if((pressed&8) && goats_m9n::state.speed_kmh<3.f){screen_=1;menu_item_=0;menu_draw_();}
   return;
 }
 if(pressed&4){if(screen_==1){screen_=0;static_layout_();status_draw_();clock_();auxiliaries_();}
   else{screen_=1;menu_item_=0;menu_draw_();}return;}
 int n=(screen_==1)?6:(screen_==3?(int)goats_tracks::tracks.size():0);
 if(n){if(pressed&1)menu_item_=(menu_item_+n-1)%n;if(pressed&2)menu_item_=(menu_item_+1)%n;}
 if(pressed&8)menu_action_();else menu_draw_();
}

void GoatsSpiDiag::setup(){
 started_=millis();heartbeat_=started_;
 for(int pin:{KEY_UP,KEY_DOWN,KEY_BACK,KEY_OK})pinMode(pin,INPUT_PULLUP);
 old_keys_=0x0F;
 goats_tracks::load();
 ESP_LOGI(TAG,"V0402 RC: laptimer RLCD originale, UBX M9N, 4 keys; circuiti=%u",
   (unsigned)goats_tracks::tracks.size());
}
void GoatsSpiDiag::loop(){
 uint32_t now=millis(),elapsed=now-started_;
 if(now-heartbeat_>=10000){heartbeat_=now;
   ESP_LOGI(TAG,"V0402 uptime=%lu stage=%u fix=%u sats=%u pvt=%.1f Hz track=%d",
    (unsigned long)(elapsed/1000),stage_,goats_m9n::state.fix,goats_m9n::state.used_sats,
    (double)goats_m9n::state.pvt_hz,track_index_);}
 if(stage_==0&&elapsed>=0){pinMode(CS,OUTPUT);digitalWrite(CS,HIGH);stage_=1;}
 if(stage_==1&&elapsed>=10){pinMode(DC,OUTPUT);digitalWrite(DC,HIGH);stage_=2;}
 if(stage_==2&&elapsed>=20){pinMode(RES,OUTPUT);digitalWrite(RES,HIGH);stage_=3;}
 if(stage_==3&&elapsed>=30){digitalWrite(RES,LOW);delay(200);digitalWrite(RES,HIGH);stage_=4;}
 if(stage_==4&&elapsed>=250){spi_.begin(SCLK,-1,MOSI,CS);
   spi_.beginTransaction(SPISettings(4000000,MSBFIRST,SPI_MODE0));stage_=5;}
 if(stage_==5&&elapsed>=300){controller_init_();stage_=6;}
 if(stage_==6&&elapsed>=900){
   static_layout_();region_(0,0,400,300,"INITIAL");
   goats_postfix::set(post_fix_mode_);
   goats_postfix::prepare();
   if(gps_uart_){goats_cfg::configure(*gps_uart_);gps_configured_=true;}
   goats_postfix::start();
   last_lap_=last_aux_=stat_start_=millis();stage_=7;
   pinMode(0,INPUT_PULLUP);
   if(diagnostics_)gps_diag_draw_();else racing_draw_();
   last_ui_=millis();
 }
 if(stage_!=7)return;
 gps_poll_();
 goats_gps_diag::stability.tick(::millis());
 goats_postfix::tick();
 boot_key_();
 now=millis();
 if(diagnostics_){if(now-last_ui_>=1000){last_ui_=now;gps_diag_draw_();}}
 else {
   // Complete a queued image before rendering the next; the GNSS owner ran first.
   if(flicker_test_)flicker_tick_();
   else if(flush_row_>=200 && now-last_ui_>=(fast_display_?125u:100u)){last_ui_=now;racing_draw_();}
   racing_flush_();
 }
 if(millis()-stat_start_>=10000){ESP_LOGI(TAG,"V0402 PERF regions=%lu bytes=%lu spi=%luus max=%luus missed=%lu",
  (unsigned long)updates_,(unsigned long)bytes_,(unsigned long)spi_us_,
  (unsigned long)max_us_,(unsigned long)missed_);
  stat_start_=millis();updates_=bytes_=spi_us_=max_us_=missed_=0;}
}

void GoatsSpiDiag::flicker_draw_(){
 using esphome::display::TextAlign;
 const uint32_t now=::millis();
 if(flicker_phase_==255)flicker_start_ms_=now;
 flicker_phase_=uint8_t(((now-flicker_start_ms_)/10000u)%2u);
 flicker_last_send_ms_=now;
 const auto ink=esphome::display::COLOR_ON,background=esphome::display::COLOR_OFF;
 canvas_.fill(background);
 canvas_.print(200,4,fonts_[2],ink,TextAlign::TOP_CENTER,goats_postfix::title());
 canvas_.print(200,36,fonts_[2],ink,TextAlign::TOP_CENTER,
   flicker_phase_?"B: INVIO - 10 SECONDI":"A: FERMO - 10 SECONDI");
 canvas_.print(200,67,fonts_[0],ink,TextAlign::TOP_CENTER,
   flicker_phase_?"STESSA IMMAGINE OGNI 125 MS":"NESSUNA SCRITTURA DOPO QUESTA IMMAGINE");
 canvas_.print(200,88,fonts_[12],ink,TextAlign::TOP_CENTER,"0");
 canvas_.print(75,193,fonts_[0],ink,TextAlign::TOP_CENTER,"NERO");
 canvas_.print(200,193,fonts_[0],ink,TextAlign::TOP_CENTER,"ROSSO");
 canvas_.print(325,193,fonts_[0],ink,TextAlign::TOP_CENTER,"BIANCO");
 rect_(20,216,110,36,BLACK);rect_(145,216,110,36,RED);border_(270,216,110,36,BLACK);
 canvas_.print(200,274,fonts_[0],ink,TextAlign::TOP_CENTER,goats_postfix::detail());
}
void GoatsSpiDiag::flicker_tick_(){
 if(!flicker_test_ || diagnostics_ || flush_row_<TH)return;
 const uint32_t now=::millis();
 const uint8_t phase=uint8_t(((now-flicker_start_ms_)/10000u)%2u);
 // A leaves LCD RAM untouched after its first frame. B resends identical bytes.
 // No power-mode, oscillator, voltage, reset or display-off command here.
 if(phase!=flicker_phase_ || (phase==1 && now-flicker_last_send_ms_>=125u)){
  if(phase==1)sent_valid_=false;
  racing_draw_();
 }
}

void GoatsSpiDiag::alignment_draw_(){
 using esphome::display::TextAlign;
 const auto ink=esphome::display::COLOR_ON,background=esphome::display::COLOR_OFF;
 canvas_.fill(background);
 canvas_.print(200,2,fonts_[2],ink,TextAlign::TOP_CENTER,lcd_high_power_?"STEP3F - PROVA HPM":"STEP3F - PROVA LPM");
 canvas_.print(200,27,fonts_[0],ink,TextAlign::TOP_CENTER,"OROLOGIO DI PROVA");
 canvas_.print(10,49,fonts_[0],ink,TextAlign::TOP_LEFT,"VERTICALI 1 PX");
 canvas_.print(210,49,fonts_[0],ink,TextAlign::TOP_LEFT,"ORIZZONTALI 1 PX");
 // Asymmetric single-pixel patterns expose an odd/even-row interchange.
 for(int x=10;x<190;x+=4)canvas_.filled_rectangle(x,70,1,49,ink);
 for(int y=70;y<119;y+=4)canvas_.filled_rectangle(210,y,180,1,ink);
 canvas_.line(10,130,389,130,ink);
 canvas_.print(200,137,fonts_[3],ink,TextAlign::TOP_CENTER,"0123456789  GPS");
 const uint32_t ui_now=::millis();char ui_clock[24];
 snprintf(ui_clock,sizeof(ui_clock),"%02lu:%02lu.%03lu",(unsigned long)((ui_now/60000)%60),(unsigned long)((ui_now/1000)%60),(unsigned long)(ui_now%1000));
 canvas_.print(200,174,fonts_[8],ink,TextAlign::TOP_CENTER,ui_clock);
 for(int i=0;i<32;i++)canvas_.draw_pixel_at(14+i,252+i,ink);
 canvas_.filled_rectangle(62,254,80,30,ink);
 canvas_.print(102,256,fonts_[2],background,TextAlign::TOP_CENTER,"GPS 123");
 rect_(160,254,35,28,BLACK);rect_(200,254,35,28,RED);border_(240,254,35,28,BLACK);
 canvas_.print(292,258,fonts_[0],ink,TextAlign::TOP_LEFT,"NERO ROSSO");
}
void GoatsSpiDiag::racing_draw_(){
 for(auto *font:fonts_)if(!font)return;
 if(flicker_test_)flicker_draw_();
 else if(alignment_test_)alignment_draw_();
 else goats_step2_render::draw(canvas_,fonts_,::millis(),delta_screen_);
 // A composed image is immutable until all its bytes have been sent.
 flush_row_=(sent_valid_ && !memcmp(framebuffer_,sent_frame_,sizeof(framebuffer_)))?TH:0;
 // Remove ESPHome's 16ms wait only while a changed image is in flight.
 if(fast_display_ && flush_row_<TH)display_loop_.start();else display_loop_.stop();
}
void GoatsSpiDiag::racing_flush_(){
 if(flush_row_>=TH){display_loop_.stop();return;}
 if(flush_row_==0){
   frame_started_ms_=::millis();
   // Exactly the full RAM window used by DIAG3 region_(0,0,400,300).
   // One RAMWR stream: never re-address partial row windows between chunks.
   cmd_(0x2A);data_(0x05);data_(0x05+TW-1);
   cmd_(0x2B);data_(0);data_(TH-1);cmd_(0x2C);
   digitalWrite(DC,HIGH);digitalWrite(CS,LOW);
 }
 const unsigned rows=std::min<unsigned>(16,TH-flush_row_);
 const unsigned offset=flush_row_*150,size=rows*150;
 const uint32_t started=micros();
 // CS and DC stay asserted between loop iterations. This SPI bus has one owner;
 // the next iteration polls GNSS before continuing this same RAMWR stream.
 spi_.transferBytes(framebuffer_+offset,nullptr,size);
 const uint32_t elapsed=micros()-started;
 bytes_+=size;spi_us_+=elapsed;if(elapsed>max_us_)max_us_=elapsed;
 memcpy(sent_frame_+offset,framebuffer_+offset,size);
 flush_row_+=rows;
 if(flush_row_>=TH){digitalWrite(CS,HIGH);sent_valid_=true;++updates_;
  last_frame_ms_=::millis()-frame_started_ms_;display_loop_.stop();}
}
void GoatsSpiDiag::racing_cancel_(){
 // Finish any open SPI frame before issuing commands for another page/mode.
 display_loop_.stop();digitalWrite(CS,HIGH);flush_row_=TH;sent_valid_=false;
}
void GoatsSpiDiag::boot_key_(){
 const uint32_t now=::millis();const bool down=digitalRead(0)==LOW;
 if(down==boot_down_ || now-boot_changed_<40)return;
 boot_changed_=now;boot_down_=down;
 if(down){boot_since_=now;return;}
 if(now-boot_since_>=3000){
   goats_postfix::record_toggle();
 }else if(now-boot_since_>=1200)delta_screen_=!delta_screen_;
 else diagnostics_=!diagnostics_;
 racing_cancel_();
 if(diagnostics_)gps_diag_draw_();else racing_draw_();
 // Keep the UI scheduler in the original component clock epoch.
 last_ui_=millis();
}

// DIAG3 stability page retained alongside Racing, selectable without external keys.
void GoatsSpiDiag::gps_diag_draw_(){
 const auto &d=goats_gps_diag::counters;
 const auto &g=goats_m9n::state;
 const auto &m=goats_gps_diag::stability;
 const uint32_t now=::millis();
 const bool fresh=m.pvt_fresh(now),position=fresh && m.fix_active;
 rect_(0,0,400,300,WHITE);
 font_text_(200,4,goats_postfix::title(),20,BLACK,1);
 char b[100];
 if(fresh){
   if(position)snprintf(b,sizeof(b),"DATI OK - %s",m.fix_name());
   else if(m.fix_type==5)snprintf(b,sizeof(b),"DATI OK - SOLO TEMPO");
   else snprintf(b,sizeof(b),"DATI OK - ATTESA FIX");
 }else snprintf(b,sizeof(b),"%s",d.status(now,false));
 font_text_(200,30,b,16,BLACK,1);
 auto large=[&](int x,int y){font_text_(x,y,b,font_width_(b,28)<=184?28:20,BLACK,0);};
 auto row=[&](int y){font_text_(8,y,b,font_width_(b,16)<=384?16:13,BLACK,0);};
 if(m.sat_fresh(now))snprintf(b,sizeof(b),"VISTI %u",g.visible_sats);else snprintf(b,sizeof(b),"VISTI --");large(8,60);
 if(fresh)snprintf(b,sizeof(b),"USATI %u",g.used_sats);else snprintf(b,sizeof(b),"USATI --");large(206,60);
 if(m.dop_fresh(now))snprintf(b,sizeof(b),"HDOP %.2f",(double)g.hdop);else snprintf(b,sizeof(b),"HDOP --");large(8,111);
 font_text_(300,82,"KM/H",13,BLACK,1);
 if(position)snprintf(b,sizeof(b),"%.1f",(double)g.speed_kmh);else snprintf(b,sizeof(b),"--");
 // Native 60px numeric speed. Align the decimal at the baseline, without
 // scaling bitmaps or changing the original shared font renderer.
 const int speed_size=font_width_(b,60)<=184?60:font_width_(b,42)<=184?42:28;
 auto speed_font=goats_font::table(speed_size);
 const int cap_height=speed_font.g[goats_font::idx('8')].h;
 int speed_x=300-font_width_(b,speed_size)/2;
 for(unsigned i=0;b[i];++i){
   const auto &glyph=speed_font.g[goats_font::idx(b[i])];
   const int offset=b[i]=='-'?(cap_height-glyph.h)/2:cap_height-glyph.h;
   const char character[]={b[i],0};
   font_text_(speed_x,94+offset,character,speed_size,BLACK,0);
   speed_x+=glyph.advance;
 }
 if(fresh)snprintf(b,sizeof(b),"PVT %.1f Hz   ETA %lu ms",(double)g.pvt_hz,(unsigned long)(now-m.last_pvt));
 else snprintf(b,sizeof(b),"PVT -- Hz   ETA %s",m.have_pvt?">1500 ms":"MAI RICEVUTO");row(145);
 const uint32_t seconds=m.continuous_fix_ms()/1000;
 snprintf(b,sizeof(b),"FIX CONT %lu:%02lu   PERSI %lu",(unsigned long)(seconds/60),(unsigned long)(seconds%60),(unsigned long)m.fix_losses);row(167);
 snprintf(b,sizeof(b),"BUCHI PVT %lu   GAP MAX %lu ms",(unsigned long)m.stream_losses,(unsigned long)m.max_gap_ms);row(189);
 if(m.have_step)snprintf(b,sizeof(b),"PASSO GPS %lu ms   ERR CK %lu",(unsigned long)m.step_ms,(unsigned long)d.checksum_errors);
 else snprintf(b,sizeof(b),"PASSO GPS -- ms   ERR CK %lu",(unsigned long)d.checksum_errors);row(211);
 snprintf(b,sizeof(b),"RX %lu UBX %lu UI %lums",(unsigned long)d.bytes,(unsigned long)d.frames,(unsigned long)last_frame_ms_);row(233);
 char sat_age[20],dop_age[20];
 if(m.have_sat)snprintf(sat_age,sizeof(sat_age),"%lu ms",(unsigned long)(now-m.last_sat));else snprintf(sat_age,sizeof(sat_age),"MAI");
 if(m.have_dop)snprintf(dop_age,sizeof(dop_age),"%lu ms",(unsigned long)(now-m.last_dop));else snprintf(dop_age,sizeof(dop_age),"MAI");
 if(goats_postfix::storage())snprintf(b,sizeof(b),"MEM %s W:%lu ID:%lu",goats_step3_store::state().stage,(unsigned long)goats_step3_store::state().write_ops,(unsigned long)goats_step3_store::state().id_commits);
 else snprintf(b,sizeof(b),goats_postfix::usb()?"TELEMETRIA FLASH OFF - USB MANAGER ON":"FLASH E USB MANAGER ESCLUSI DAL TEST");row(255);
 if(goats_postfix::backend())snprintf(b,sizeof(b),"USB:%u REC:%u C:%lu P:%u PT:%lu D:%lu",goats_step3_usb::state().ready,goats_step3_store::state().active!=0,(unsigned long)goats_b::state().pvt_samples,(unsigned)goats_b::state().tracks.size(),(unsigned long)(goats_step3_store::state().count?goats_step3_store::state().sessions[goats_step3_store::state().count-1].points:0),(unsigned long)(goats_step3_store::state().active?goats_step3_store::state().dropped:goats_step3_store::state().last_dropped));
 else snprintf(b,sizeof(b),"CORE:%s C:%lu - BOOT BREVE: TEST/INFO",goats_postfix::mode==goats_postfix::GPS_ONLY?"OFF":"ON",(unsigned long)goats_b::state().pvt_samples);
 font_text_(200,282,b,13,BLACK,1);
 region_(0,0,400,300,"GPS-DIAG3");
}

void GoatsSpiDiag::dump_config(){ESP_LOGCONFIG(TAG,"RC3.3 STEP3F: mode %s, LCD %s, NO SD/ADC",goats_postfix::name(),lcd_high_power_?"HPM 51Hz nominal":"LPM");}
}}
